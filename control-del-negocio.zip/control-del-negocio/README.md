# Control del Negocio — app independiente

App para gestionar **pedidos y ruta**, **pagos y alertas**, y **vales de empleados**,
con entrada por usuario y registro diario de toda la actividad.

A diferencia de la versión hecha dentro de Claude, esta es un proyecto normal de
React que puedes hospedar en tu propio dominio e instalar como app en tu celular
(PWA). Los datos ya no viven en Claude: viven en una base de datos **Supabase**
(gratis) que tú controlas, así que nunca se pierden, se pueden ver desde
cualquier dispositivo, y sobreviven a refrescar la página, cerrar el navegador
o cambiar de celular.

## 1. Crear la base de datos (Supabase, gratis)

1. Entra a https://supabase.com y crea una cuenta gratis.
2. Crea un proyecto nuevo (elige una contraseña de base de datos y guárdala).
3. En el menú izquierdo, entra a **SQL Editor** → **New query**.
4. Abre el archivo `supabase/schema.sql` de esta carpeta, copia todo su
   contenido, pégalo ahí y dale **Run**. Esto crea las tablas de pedidos,
   empleados, vales, usuarios y la bitácora.
5. Ve a **Project Settings → API Keys**. Ahí vas a encontrar:
   - **Project URL**
   - **Publishable key** (empieza con `sb_publishable_...`). Si tu proyecto es
     más antiguo y en vez de eso ves una **anon public key**, sirve igual —
     usa la que te aparezca.

## 2. Configurar la app con tus datos de Supabase

1. Instala Node.js (versión 18 o más nueva) si no lo tienes: https://nodejs.org
2. En esta carpeta, copia `.env.example` a un archivo nuevo llamado `.env`:
   ```
   cp .env.example .env
   ```
3. Abre `.env` y reemplaza los valores con los tuyos:
   ```
   VITE_SUPABASE_URL=https://tu-proyecto.supabase.co
   VITE_SUPABASE_ANON_KEY=tu-publishable-key (o tu anon key, si es lo que ves)
   ```

## 3. Probar en tu computador

```
npm install
npm run dev
```

Abre la dirección que te muestre la terminal (normalmente `http://localhost:5173`).
Ya deberías poder entrar con un usuario y registrar pedidos.

## 4. Publicar la app en tu propio dominio (gratis)

La forma más simple es con **Vercel** o **Netlify**:

1. Sube esta carpeta a un repositorio de GitHub (puedes usar GitHub Desktop si
   no manejas Git desde la terminal).
2. Entra a https://vercel.com (o https://netlify.com), conecta tu cuenta de
   GitHub y elige este repositorio.
3. En la configuración del proyecto, agrega las mismas dos variables del
   paso 2 (`VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY`) en la sección de
   **Environment Variables**.
4. Dale **Deploy**. En un par de minutos te da un link (ej:
   `control-del-negocio.vercel.app`) — ese ya es tu link definitivo. Si tienes
   un dominio propio, ambos servicios te dejan conectarlo gratis desde su
   panel ("Domains").

## 5. Instalarla en el celular (como app, sin tienda de apps)

Esta app ya viene lista como **PWA** (Progressive Web App):

- **Android (Chrome):** abre el link de tu app → menú (⋮) → "Instalar app" o
  "Agregar a pantalla de inicio".
- **iPhone (Safari):** abre el link → botón de compartir (□↑) → "Agregar a
  pantalla de inicio".

Va a quedar como un ícono más en el celular, se abre a pantalla completa y
funciona igual que cualquier app instalada.

## Estructura del proyecto

```
control-del-negocio/
├── index.html
├── package.json
├── vite.config.js            # build + configuración de la PWA
├── tailwind.config.js
├── .env.example               # copiar a .env con tus datos de Supabase
├── supabase/
│   └── schema.sql             # correr una vez en Supabase (crea las tablas)
├── public/
│   ├── icon-192.png            # ícono de la app (cámbialo si quieres tu logo)
│   └── icon-512.png
└── src/
    ├── main.jsx                # punto de entrada
    ├── App.jsx                 # arma la pantalla, conecta todo con Supabase
    ├── supabaseClient.js        # conexión a la base de datos
    ├── index.css
    ├── lib/
    │   ├── db.js                # todas las lecturas/escrituras a Supabase
    │   └── utils.js              # formato de fechas, moneda, etc.
    └── components/
        ├── ui.jsx                # botones, tarjetas, modal, etc.
        ├── LoginScreen.jsx        # pantalla de "¿quién va a usar la app?"
        ├── Pedidos.jsx             # pedidos y ruta, con navegación por día
        ├── Pagos.jsx               # cobros pendientes por cliente
        ├── Empleados.jsx           # empleados y sus vales
        └── Actividad.jsx           # bitácora diaria de todo lo que se hizo
```

## Notas importantes

- **Seguridad:** por ahora cualquiera con el link puede entrar (el "usuario"
  es solo para identificar quién hizo cada acción, no es una contraseña). Es
  apropiado para un equipo pequeño y de confianza. Si más adelante quieres que
  cada persona tenga su propia clave, se puede agregar autenticación real de
  Supabase — avísame y lo armamos.
- **Respaldo:** el botón "Respaldo" del header sigue funcionando y descarga un
  `.json` con todo. Como los datos ya viven en Supabase (que también hace sus
  propios respaldos automáticos), esto es una copia extra de tranquilidad, no
  la única fuente de tus datos.
- **Costo:** el plan gratis de Supabase y de Vercel/Netlify alcanza de sobra
  para el uso diario de un negocio como el tuyo. Si en algún momento creces
  mucho, ahí recién tocaría evaluar un plan pago.
