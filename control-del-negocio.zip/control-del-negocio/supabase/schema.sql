-- ============================================================
-- Control del Negocio — esquema de base de datos (Supabase)
-- Copia y pega todo este archivo en Supabase > SQL Editor > Run
-- ============================================================

create extension if not exists "pgcrypto";

-- Usuarios (solo nombres, para identificar quién hace cada acción)
create table if not exists usuarios (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

-- Empleados
create table if not exists empleados (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

-- Pedidos entregados en ruta
create table if not exists pedidos (
  id uuid primary key default gen_random_uuid(),
  client text not null,
  route text,
  date date not null,
  payment_status text not null check (payment_status in ('efectivo', 'transferencia', 'pendiente')),
  due_date date,
  total numeric not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_pedidos_date on pedidos (date);

-- Vales de empleados
create table if not exists vales (
  id uuid primary key default gen_random_uuid(),
  employee_id uuid references empleados (id) on delete cascade,
  amount numeric not null,
  date date not null,
  reason text,
  deducted boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_vales_employee on vales (employee_id);

-- Bitácora de actividad diaria
create table if not exists bitacora (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  time text not null,
  user_name text not null,
  action text not null,
  detail text,
  created_at timestamptz not null default now()
);
create index if not exists idx_bitacora_date on bitacora (date);

-- ------------------------------------------------------------
-- Seguridad (RLS): habilitada con una política simple que
-- permite leer y escribir a cualquiera que tenga la clave
-- "anon" de tu proyecto (la que va en el .env de la app).
-- Es apropiado para un equipo pequeño y de confianza que solo
-- usa esta app. Si más adelante quieres login con contraseña
-- por persona, se puede endurecer usando Supabase Auth.
-- ------------------------------------------------------------

alter table usuarios enable row level security;
alter table empleados enable row level security;
alter table pedidos enable row level security;
alter table vales enable row level security;
alter table bitacora enable row level security;

create policy "acceso total usuarios" on usuarios for all using (true) with check (true);
create policy "acceso total empleados" on empleados for all using (true) with check (true);
create policy "acceso total pedidos" on pedidos for all using (true) with check (true);
create policy "acceso total vales" on vales for all using (true) with check (true);
create policy "acceso total bitacora" on bitacora for all using (true) with check (true);
